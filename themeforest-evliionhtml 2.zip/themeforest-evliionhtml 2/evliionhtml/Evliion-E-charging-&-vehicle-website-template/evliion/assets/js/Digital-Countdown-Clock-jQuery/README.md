# jquery-countdown-timer
Lightweight countdown timer plugin.

**Install via npm**

https://www.npmjs.com/package/jquery-countdown-timer

**Demo**

https://shibulijack.github.io/jquery-countdown-timer/
